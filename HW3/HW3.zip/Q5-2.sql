CREATE TABLE neighbour (name varchar(100), geom geometry);

INSERT INTO neighbour VALUES
	('Troy Hall', ST_GeomFromText('POINT(-118.2824471 34.0253189)')),
	('McCarthy', ST_GeomFromText('POINT(-118.2849127 34.0251982)')),
	('Leavey', ST_GeomFromText('POINT(-118.2830789 34.0216804)')),
	('Jeff-Fig', ST_GeomFromText('POINT(-118.280642 34.0221683)')),
	('Fig-Expo', ST_GeomFromText('POINT(-118.2827975 34.0184994)')),
	('Expo-Ver', ST_GeomFromText('POINT(-118.2918534 34.018511)')),
	('SmartNFinal', ST_GeomFromText('POINT(-118.2921687 34.0225428)')),
	('RTH', ST_GeomFromText('POINT(-118.2899257 34.0201366)')),
	('Bookstore', ST_GeomFromText('POINT(-118.286483 34.020655)')),
	('Aquatics', ST_GeomFromText('POINT(-118.288581 34.023958)')),
	('Jeff-Ver', ST_GeomFromText('POINT(-118.2926756 34.0254692)'));


SET @home = ST_GeomFromText('POINT(-118.2801651 34.0264597)');

SELECT
    P.name,
    ST_AsText(P.geom) as Coordinates,
    ST_DISTANCE(@home, P.geom) AS dist
FROM neighbour P
ORDER BY dist
LIMIT 4
