Programming Language used: MySQL

Q6) Jsfiddle Link:-

http://jsfiddle.net/tLqh53xb/3/